# React

This course is designed to help you to be able to develop web applications using React

## Getting Started

## Prerequisites

1. [CLI](Prerequisites/CLI/README.md)
1. [HyperText Markup Language](Prerequisites/HTML/README.md) - By [Ozzie](https://github.com/nehero) 
