# Lesson 01 - HTML Introduction

Let's start off small and create a spinoff of the Hello World application that we went over in the slides.

# Exercise Instructions

1. Create an `index.html` file inside this folder
2. Write all of the necessary boilerplate (`<html>`, `<head>`, `<body>`, etc)
3. Set the title to `Exercise 01`
4. Create an `h1` tag saying `Hello, ComIT!`

## Bonus

1. Place a `paragraph` tag underneath the heading with a message of your choice

# Exercise Result

![Exercise 01 result](result.png)
